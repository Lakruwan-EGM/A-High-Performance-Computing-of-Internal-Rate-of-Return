#!/usr/bin/env python
# coding: utf-8

# In[1]:


number = int(input("Enter number of cash flows: "))


# In[2]:


cashflow = []
for i in range(number):
    amount = float(input("Enter cash flow amount: "))
    cashflow.append(amount)


# In[3]:


tolerance = float(input("Enter tolerance value: "))


# In[4]:


max_iterations = int(input("Enter maximum iteration count: "))


# In[8]:


C0 = abs(cashflow[0])
N = len(cashflow)
sum_Ci = sum(cashflow)
exp = 1/(((N-1)/2)+1)


# In[18]:


discount = ((sum_Ci/C0)**exp)-1
print(discount)


# In[19]:


def npv_ret(cashflow,discount):
    npv = 0
    for i in range(len(cashflow)):
        npv += cashflow[i]/(1+discount)**i
    return npv


# In[20]:


def derivative(cashflow,discount):
    der = 0
    for i in range(len(cashflow)):
        der -= i*cashflow[1]/(1+discount)**(i+1)
    return der


# In[21]:


for i in range(max_iterations):
    npv = npv_ret(cashflow,discount)
    der = derivative(cashflow,discount)
    a = discount
    discount = discount - npv/der
    error = abs(a - discount)
    if error <= tolerance:
        break
else:
    print("Maximum iterations reached without convergence")

print("i = ",i)
print("error = ",error)
print("discount rate = ",discount)


# In[ ]:





# In[ ]:




