# Define the function to calculate the net present value (NPV)
calculate_npv <- function(cash_flows, discount_rate) {
  npv <- sum(cash_flows / (1 + discount_rate)^(1:length(cash_flows)))
  return(npv)
}

# Define the derivative of the NPV function
calculate_derivative <- function(cash_flows, discount_rate) {
  derivative <- sum(cash_flows * (1:length(cash_flows)) / (1 + discount_rate)^(1:length(cash_flows) + 1))
  return(derivative)
}

# Define the Newton-Raphson method to find the discount rate that yields a NPV of zero
newton_raphson <- function(cash_flows, initial_guess, tolerance, max_iterations) {
  discount_rate <- initial_guess
  iteration <- 0
  
  while (iteration < max_iterations) {
    npv <- calculate_npv(cash_flows, discount_rate)
    derivative <- calculate_derivative(cash_flows, discount_rate)
    
    discount_rate <- discount_rate - npv / derivative
    
    if (abs(npv) < tolerance) {
      break
    }
    
    iteration <- iteration + 1
  }
  
  if (iteration == max_iterations) {
    warning("Maximum number of iterations reached without convergence.")
  }
  
  return(discount_rate)
}


# Example usage
cash_flows <- c(-100, 50, 50, 50, 50)
initial_guess <- 0.1
tolerance = 0.001
max_iterations = 10000

discount_rate <- newton_raphson(cash_flows, initial_guess, tolerance, max_iterations)
discount_rate

