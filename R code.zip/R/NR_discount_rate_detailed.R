# Function to calculate Net Present Value (NPV)
calculate_npv <- function(cash_flows, discount_rate) {
  npv <- 0
  for (i in 1:length(cash_flows)) {
    npv <- npv + cash_flows[i] / (1 + discount_rate)^i
  }
  return(npv)
}

# Function to calculate derivative of NPV with respect to discount rate
calculate_derivative <- function(cash_flows, discount_rate) {
  derivative <- 0
  for (i in 1:length(cash_flows)) {
    derivative <- derivative - i * cash_flows[i] / (1 + discount_rate)^(i + 1)
  }
  return(derivative)
}

# Define the Newton-Raphson method to find the discount rate that yields a NPV of zero
newton_raphson <- function(cash_flows, initial_guess, tolerance, max_iterations) {
  discount_rate <- initial_guess
  iteration <- 0
  
  while (iteration < max_iterations) {
    npv <- calculate_npv(cash_flows, discount_rate)
    derivative <- calculate_derivative(cash_flows, discount_rate)
    
    # x1 = x0 - f(0)/f'(0)
    discount_rate <- discount_rate - npv / derivative
    
    if (abs(npv) < tolerance) {
      break
    }
    
    iteration <- iteration + 1
  }
  
  if (iteration == max_iterations) {
    warning("Maximum number of iterations reached without convergence.")
  }
  
  return(discount_rate)
}


# Example
cash_flows <- c(-100, 50, 50, 50, 50)
initial_guess <- 0.1
tolerance = 0.001
max_iterations = 1000


discount_rate <- newton_raphson(cash_flows, initial_guess, tolerance, max_iterations)
discount_rate

